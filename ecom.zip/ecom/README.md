# ecom
Un site ecommerce basique avec intégration paypal
Un projet ecommerce avec php 7 pour s'exercer.

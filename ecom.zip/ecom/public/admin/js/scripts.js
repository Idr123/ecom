$(document).ready(function(){

$('.image_container').click(function () {
    
    var user_input;

    return user_input = confirm("Are you sure you want to delete this slide");
    location.reload();
 
});



});